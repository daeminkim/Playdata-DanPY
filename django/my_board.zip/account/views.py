from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView
from .forms import CustomUserCreationForm
from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import AuthenticationForm

#가입 View
class UserCreateView(CreateView):
    template_name = "account/join_form.html"
    form_class = CustomUserCreationForm
    success_url = reverse_lazy('home')  # urls.py config에 home 이있고 app_name이없어서 바로 이름으로 감 prefix없이

#로그인 처리 View
class UserLoginView(LoginView):
    template_name ='account/login_form.html'
    form_class = AuthenticationForm #로그인 성공하면 홈으로 가는걸  settings.py에 넣어놨음
