# 모델폼 만드는 거임 ~
from django.forms import widgets
from account.models import CustomUser
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model # settings.py 에 등록된 AUTH_USER_MODEL 클래스를 반환.
from django import forms
# CustomUser와 연동된 ModelForm
class CustomUserCreationForm(UserCreationForm):

    password1 = forms.CharField(label = 'Password', widget = forms.PasswordInput()) # widget-> 비번입력할때 그대로 노출되서 설정함./기본위젯을 바꿈.
    password2 = forms.CharField(label = 'Password 확인', widget = forms.PasswordInput())

    class Meta:
        model = get_user_model()
        fields = ['username', 'password1', 'password2','name','email', 'gender'] 
        # 필드명만 알려주면 자동으로 form을 만들어 주는데 이런애들 widget 바꾸려면
        #model의 Field들의 widget(입력양식)을 변경하고자 할때 widgets 속성에 딕셔너리 안에 등록한다. (필드명:widget객체)
        # widgets ={
        #     "name" : forms.Textarea
        # }