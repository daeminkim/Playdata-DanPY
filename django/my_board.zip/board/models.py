from django.db import models
from account.models import CustomUser

# 글의 카테고리를 저장~
class Category(models.Model):
    # pk - 자동증가 정수 컬럼
    category_code = models.AutoField(primary_key=True)  # 생략하면 id라는 컬럼의 자동증가 가 생성
    # CharField() 문자열 필드
    category_name = models.CharField(max_length= 200, verbose_name="글 카테고리") # verbose_name:화면에 나올때 라벨명

    def __str__(self):
        return  f"{self.pk}. {self.category_name}" 


# 게시물(글)저장
# title , content(글내용), create_at(등록 일시), update_at(수정일시), writer(글쓴 사람 - 후에 추가.)
class Post(models.Model):
    #글 작성자 컬럼 추가. -> account.models.CustomUser 참조
    writer = models.ForeignKey(CustomUser, on_delete= models.SET_NULL, verbose_name= '작성자', null=True, blank =True)


    title = models.CharField(max_length=255, verbose_name= "글제목") # NoT NULL , 반문자열 허용안함 디폴트로 null =false, blank =False 이기때문
    content = models.TextField(verbose_name= "글내용") # TextField : 대용량 text
     # 부모테이블의 값이 없어지면 null로 채워~ // null = False(기본값) -> notnull이라는 뜻이다. True면 null허용 컬럼
    # blank = False(기본) : 빈 문자열 허용 여부 .
    category = models.ForeignKey(Category, on_delete= models.SET_NULL, verbose_name="글 분류", null = True, blank= True) 
    # 작성일시. auto_now_add = True(기본값 : False) -> insert 시점의 일시를 저장하고 그 이후에는 update하지 않음.
    create_at = models.DateTimeField(verbose_name= '작성일시', auto_now_add= True)
    # 수정일시 auto_now =True( 기본값 :False) -> insert, update할 때마다 그 시점의 일시를 저장.
    update_at = models.DateTimeField(verbose_name= '수정일시', auto_now = True)

    ######업로드 파일 관련 Field 선언 // 수정했을때 DB에만 없어지고 프로 젝트에서는 안없어짐
    #일반파일
    up_file = models.FileField(verbose_name="업로드 파일", upload_to="files", #media/files 아래에 파일들 저장.
                                null= True, blank= True, # null값을 가질수 없는 컬럼
                                )
    # 이미지 파일 - ImageField 사용하려면 Pillow 패키지를 설치 해야함.
    up_image = models.ImageField(verbose_name='업로드 이미지', upload_to= "image/%Y/%m/%d",
                                null = True , blank = True)  # 모델 변경했으니까 makemigratioins 해주기  /migrate 도 하기 



    def __str__(self):
        return f"{self.pk}. {self.title}"
 


