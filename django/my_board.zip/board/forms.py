from django import forms
from .models import Post  # 모델 폼은 모델을 갖고 만드니까.

#form 클래스 - > forms.Form 상속 받아서 만든다
#ModelForm 클래스 -forms.ModelForm 상송
class PostForm(forms.ModelForm):
    #내부 클래스(Nested/Inner)로 Meta 클래스를 정의 -> ModelForm관련 설정

    class Meta:
        model = Post # Form을 만들때 참조할 Model클래스 지정.
        #writer는 글입력 양식에 안나오도록 처리.
        exclude = ['writer']  #폼에도 안나오고  //모델이 바뀌었기 때문에 makemigration, miagrate 해줘야함.. 
        # 모델이 바뀔때마다. makemigration, miagrate 해줘야함
        #fields = "__all__" # create_at, update_at은 auto_now(자동 등록) 했기 때문에 Form Field로 사용 안함.
         # Model의 Field들 중  Form Field로 만들 Field들 지정. 모두다 지정할 경우 문자열로 __all__지정
         # 몇몇개만 지정할 경우 리스트에 Field이름을 지정한다. ex)fields =['content', 'title']
         #특정 Field를 제외한 나머지로 지정할 경우 exclude =['title'] #title빼고 나머지
