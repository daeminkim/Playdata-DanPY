
from django.shortcuts import redirect, render
from django.views.generic import CreateView, DetailView, UpdateView, ListView
from django.urls import reverse_lazy

from django.contrib.auth.decorators import login_required #로그인 여부를 확인해서 로그인 안한경우 settings.py의 LOGIN_URL의 경로로 이동/함수는 이것을 바로 사용 class는 밑에꺼를 사용해서 데코레이터 사용
from django.utils.decorators import method_decorator # class 의 메소드에 decorator를 선언해 주는 decorator

from django.views.generic.list import ListView
from .forms import PostForm
from .models import Post

############################### post 해서 버튼 누르는 것 이외에 링크를 누르거나 주소창에 넣는거는 다get 방식이다.

# 글 등록
# Createview 등록 (저장 - insert처리)
#   get방식 요청 : 입력양식 화면으로 이동(render())
#   post 방식 요청 : 입력 (등록)처리.
                # 처리 성공 : 성공페이지로 이동 (redirect())
                # 처리 실패  : 입력양식 화면으로 이돌(render())

# 로그인 한 사용자만 호출할 수 있는 기능.
# 글 작성자를 추가. //글쓰기 폼에서 작성자를 없앴기때메 DB에 등록이 자동으로 되지 도않고 등록할 수가 없으니까 여기서 추가
#writer -> 글을 작성한(로그인한) 사용자의 CustomUser객체를 사용.
from django.contrib.auth import get_user # 로그인한 사용자의 User Model객체를 반환.

@method_decorator(login_required, name='dispatch') #dispatch()메소드에 @login_required 장식자를 적용해라.
class PostCreateView(CreateView): # 등록화면을 만드는 것과 등록하는 것을 createView가 해주는 것이다.
    template_name ='board/post_create.html'  # 입력양식 화면 template경로
    form_class = PostForm # 요청파라미터를 처리할 Form 을 지정.
    #success_url = reverse_lazy("board:detail")  # 등록 처리후 이동할 경로 ->redirect 방식이동 => view의 url을 등록//
    # 여기(class에선 객체가 생성되기 전에 success_url이 실행되므로)에선 바로 등록된 객체의 pk를 조회할 수없어서 get_success_url 메서드를 오버라이딩 한것이다.
    # redirect 방식이니까 다시 요청할..  url을 넣어줘야한다
    # success_url 설정을 대신하는것이다


    #  success_url에서 insert한 Model 객체를 접근하려면 이메소드를 overriding 해야한다.
    #  insert한 모델 객체 조회 : self.object
    def get_success_url(self): #5/31일 5교시 이후 강의 동영상에 설명있음.
        # 반환값 : 등록 성공후 redirect방식 으로 이동할 View의 url을  문자열로 반환.
        return reverse_lazy('board:detail', args =[self.object.pk]) # args: path parameter로 전달할 값들을 리스트에 순서대로 담는다.

    # CreateView, UpdateView에서 Post 요청 처리시 insert/delete 하기 전/후로 해야하는 작업이 있을 경우 form_valid()를 오버라이딩 한다.
    # 로그인한 사용자의 User 모델객체를 insert하기 전에 model에 넣어준다.
    # 매개변수: form - (검증을 통과한.)ModelForm을 첫번째 매개변수로 받는다.  / 이부분 설명 5교시 중반쯤..//form에직접적으로 값을 변경할 수는 없다
    def form_valid(self, form):
        post = form.save(commit =False) #ModelForm.save(): Model객체가 반환
        post.writer = get_user(self.request)#로그인한 User객체 
        # post.save(): 최종 update&commit ->super 에서 처리 
        return super().form_valid(form)

#http://ccbv.co.uk/
# get방식으로 요청이 오면 template_name 에잇는 경로로 가서 form_class를 이용해서 폼을 제공하고 거기서 검증이 성공하면 success_url로 redirect방식으로
# url을 전달하는 일을 한다.



# 하나의 글 정보조회 (pk로)
# DetailView - pk로 조회한 결과를 template으로 보내주는 genericView
# url 패턴 :pk를 path 파라미터로 받는다. <type:pk> 변수명을 pk로 지정해야 한다.  
#                                     이 path parameter값을 이용해 select.


class PostDetailView(DetailView):
    template_name ="board/post_detail.html"  #응답할 templat의 경로.
    # pk로 조회할 Model클래스. 조회 결과를 "post"(모델클래스명을 소문자),"object"라는 이름으로 template에게 전달.
    model = Post 
    # DB에 등록될때 pk값이 있겠지.? 그걸로 피케이값을 받아서 조회 한다.

# path("detail/<int:pk>", DetailView.as_view(template_name ='board/post_detail.html', model= Post), name ='detail')


# 글 수정 처리
# UpdateView (정보수정)
#  - Get 요청처리: pk로 수정할 정보를 조회해서 template(수정 form)으로 전달(render())
#  - Post 요청처리 : update 처리. (redirect방식으로 View를 요청)
#  - template_name : 수정 form template 파일의 경로
#  - form_class : Form/ModelForm 클래스 등록
#  - model : Model 클래스 등록 (수정폼 template에 전달할 값<전에 작성햇던 것을 그대로 줘야하니까>을 조회하기 위해)
#  - success_url : 수정 처리후 redirect 방식으로 이동할 View의 url (path parameter로 update한 Model정보를 사용할 경우 get_success_url()을 오버라이딩)
# 로그인 한 사용자만 호출 가능
@method_decorator(login_required, 'dispatch') # 로그인만 하면 수정 할 수 있는 거를 막아줘야한다. 
class PostUpdateView(UpdateView):
    template_name = "board/post_update.html"
    form_class = PostForm
    model = Post # 여기서 pk값을 갖고 조회해라 그것을 template에 전달하셈

    def get_success_url(self):
        return reverse_lazy('board:detail', args=[self.object.pk]) # 수정이 완료되면 detail로 가야되니까.


# 삭제처리
# generic View :DeleteView를 사용 -> 삭제 확인 화면을 거쳐서 삭제 처리한다.
# 함수 기반으로 작성. path parameter로 삭제할 글의 id(pk)를 받아서 삭제 처리.

#로그인 한 사용자만 호출
@login_required
def post_delete(request, pk):  # 삭제할 화면도 만들어야하고 해서 간단하게 함수 형으로 만듦
    #try:
    post = Post.objects.get(pk=pk) #삭제할 데이터 조회
    #except:
    #       에러페이지 이동.
    post.delete() #post객체의 pk와 동일한 데이터를 삭제.// 

    return redirect("/") #반복적으로 삭제 되는것을 막기 위해 redirect함 

# 글 목록 을 보여주는 
#ListView 구현
# template_name : 결과를 보여줄 template의 경로
# model :조회할 모델 클래스를 지정
# 조회 결과를  template에 "object_list", "모델이름 소문자_list" 라는 이름으로 전달.
#ListView는 paging 기능 지원

class PostListView(ListView):
    template_name = "board/post_list.html"
    model = Post  #리스트로 나올 것들을 조회할 모델.. Post.objects.all() 
# 특별한 로직이없을때는 class 안만들고 바로 이렇게 써도 된다.
#path('list', ListView.as_view(template_name ='board/post_list.html', model = Post), name ='list) 

    # 페이징 처리
    # class변수 : paginate_by = 한페이지의 데이터 개수
    # 요청시 url : url?page=번호 ex) http:/127.0.0.1:8000/board/list?page=2   page를 생략하면 1번페이지를 조회.
    # 페이지 번호를 template에서 출력하기 위한 값들을 만들어서 template에 전달. ->get_text_data()를 오버라이딩.
    paginate_by = 10  #한페이지에 10개씩  데이터 뿌린다.
    ##
    # context data = view가 template에게 전달하는 값. key-value쌍. key:context name, value: context value
    # get_context_data(): Generic View를 구현할 때 template에게 전달해야하는 context data(여기선 페이지관련 data)가 있을 때 오버라이딩 해서 전달할 값을 만든다.
    # 페이징관련 값들을 context data에 추가 
    # - 이전/다음 페이지 그룹 유무(그룹의 시작/끝페이지)
    # - 이전/다음 페이지 번호(그룹의 시작/끝페이지)
    # - 현재 페이지가 속한 페이지 그룹의 페이지 범위(시작~끝 페이지 번호)
    def get_context_data(self, **kwargs): # kwargs : 페스파라미터 받을 변수. 
        # 부모객체의 get_context_data()를 호출해서 generic view가 자동으로 생성한 Context data를 받아온다.
        context = super().get_context_data(**kwargs)
        # ListView에서 Paginator_by 속성을 설정하면 contextdata에 Paginator객체가 등록 된다.
        paginator = context['paginator']  # 객체 등록 되있는거 갖고옴 우ㅣ에 paginator_by 를 했기 때문에 잇음
        page_group_count = 10  # 페이지그룹에 속한 페이지 개수
        current_page = int(self.request.GET.get('page',1)) # 페이지라는 이름으로 넘어온 값을 current_page로 할건데 없으면 1로하겠다.
        # 딕셔너리의 get을 쓴것이다. 값이없으면 디폴트 값으로 1을 사용하겠다.
        # CBV에서 HttpRequest는 self.request로 사용할 수 있다.

        # 페이지 그룹의 페이지 범위 조회
        start_idx= int((current_page-1)/page_group_count)*page_group_count
        end_idx = start_idx +page_group_count
        page_range = paginator.page_range[start_idx:end_idx]

        # 그룹의 시작 페이지가 이전페이지가 있는지, 그룹의 마지막페이지가 다음페이지가 있는지 여부+ 페이지 번호.
        start_page = paginator.page(page_range[0]) #시작 페이지의 Page객체 / 첫번째 페이지의 index를 넣어 페이지 번호를 갖고옴
        end_page = paginator.page(page_range[-1])  # 마지막 페이지의 page객체 / 그룹에서 마지막 페이지의 index를 넣어 페이지 번호를 갖고옴

        has_previous= start_page.has_previous() # 시작의 이전 페이지가 있는지 여부 True/False로 나온다.
        has_next = end_page.has_next() #마지막 페이지의 다음 페이지가 있는지 여부 

        context['page_range'] = page_range
        #이전페이지 그룹으로 , 다음페이지 그룹으로 갈때 사용 이전,다음 페이지가 없다면 버튼 안 만들거임.
        if has_previous:
            context['has_previous'] = has_previous
            context['previous_page_no'] = start_page.previous_page_number # 시작페이지의 이전페이지 번호

        if has_next:
            context['has_next'] = has_next
            context['next_page_no'] = end_page.next_page_number #마지막 페이지의 다음 페이지 번호

        return context


    

