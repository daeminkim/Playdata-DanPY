from django.urls import path
from django.views.generic import TemplateView
from . import views

app_name ='board'

#사용자 호출 -> View.as_view() -> disptch() 다음 호출이 분기
# GET요청 : dispatch() -> get()
# PoST요청 : dispatch() -> post() ->
# def dispath(request,..):
#     if request.method ==GET:


urlpatterns=[  # 비어있더라도 이변수가 꼭있어야함..
    path('detail/<int:pk>', views.PostDetailView.as_view(),name='detail'), #게시물 상세페이지 
    path('create', views.PostCreateView.as_view(),name ='create'), #글등록 View url
    path('update/<int:pk>', views.PostUpdateView.as_view(), name= 'update'), # 글 수정 url. GET:수정할 게시물의 pk를 Path parameter 받아야함.
    path('delete/<int:pk>', views.post_delete, name = 'delete'), # 삭제 처리하는 .. 
    path('list', views.PostListView.as_view(), name ='list'), # 글 목록 조회 .
]