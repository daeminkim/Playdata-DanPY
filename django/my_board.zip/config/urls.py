"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path("", TemplateView.as_view(template_name = 'home.html'), name ='home' ), # 사용자는 여기에 template을 넣을 수없어서 View를 사용.class기반 
    path('admin/', admin.site.urls),                                                # class 기반 뷰에 TemplateView가 있음.
    path('board/', include('board.urls')),
    path('account/', include('account.urls')),
]


###########################################################################
# 업로드된 파일을 client가 요청할 수 있도록 처리. 다운로드 받을 수 있게 하려면 미디어 url에 관련 된거를 static으로 바꿔줘야함..
###########################################################################
from django.conf.urls.static import static
from . import settings    # config 밑에 settings.py 임포트 // MEDIA_URL, MADIA_ROOT 를 사용하기 위해서 IMPORT 함. 
urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
#Upload 된 파일들을 static 파일로 서비스 하기 위한 설정(url시작 path, media 파일의 root디렉토리.)