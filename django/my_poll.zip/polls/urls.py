# urls.py  url - view를 연결  -> 컽피그에 모든 urlpatterns를 하기에 무리가 잇어서 앱에 만들어서 config에등록한다.
# polls/urls.py -> polls app 용 url pattern 설정 스크립트
from django.urls import path
from . import views

# 이 url pattern들의 namespace(prefix)로 사용하 값 설정
# urlpattern 설정의 이름 호출시 다른 app 들과 구분하기 위해 사용한다.
app_name ='polls'

urlpatterns =[
    path("list", views.list, name ='list'),  # 여기에 urls를 등록 시켰으니 다른 프로젝트에 가서도 configurl에만 등록 시켜 주면 된다 
    path("vote_form/<int:question_id>", views.vote_form, name='vote_form'),
    path("vote", views.vote, name ='vote'),
    path("vote_result/<int:question_id>",views.vote_result, name ='vote_result'),

]