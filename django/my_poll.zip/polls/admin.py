from django.contrib import admin
from .models import Question, Choice # 같은경로에 있는 models에서 Question,Choice import
# Register your models here.

admin.site.register(Question) # 이곳에 등록했기 때문에 서버 실행하면 admin할수있게 해주는것이다.
admin.site.register(Choice)
