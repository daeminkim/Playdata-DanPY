from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Question, Choice
from django.urls import reverse  # reverse함수: path 설정 이름으로 url 문자열을 만들어 주는 함수.
#polls/views.py
# 질문 목록을 보여주는 Veiw
# View 로직 순서
# 1. 사용자가 보내준 값(있다면,없으면 안함)에 대한 검증 / 타입 변경
# 2. Business Logic 처리.
# 3. 결과 응답.
#                       /app이름
# http://127.0.0.1:8000/polls/lsit
def list(request): # 
    # business logic -> 질문을 DB 조회
    question_list = Question.objects.all().order_by('-pub_date')
    for q in question_list:
        print(q.id, q.question_text, q.pub_date)

    # template 을 호출 - render(request, "template의 경로(html의경로)",[template에 전달할값- dictionary(생략가능)])
    return render(request,  #– Django template 스크립트를 해석하여 사용자에게 응답할 최종 HTML을 생성한다
                  'polls/list.html', # 화면을 호출하면서 
                   {"question_list":question_list}) # 이 값을 전달 해~  // heml 에 넣을 때 반복문 돌릴때 key 값으로 넣어주는것이다.


# vote_form Veiw (한개 질문에 대한 정보를 조회해서 응답.)
def vote_form(request, question_id):
    print('vote_form', question_id)
    #question_id 질문 조회
    try:
        question = Question.objects.get(pk = question_id)
        return render(request, "polls/vote_form.html",{"question":question}) 
    # templates/ 이거 안넣어 줘도됨// key값으로 html파일에 넣는거임
    #hteml 에서 변수로 출력을 하려고 할땐 {{}} 중괄호 두개 --> vote_form.html 보기 

    except:
        return render(request, 'polls/error.html',
                      {'error_message' : "없는 질문을 조회했어"})

# 투표처리 : 선택된 Choice의 vote 값을 1증가
# /polls/vote
def vote(request):
    #요청 파라미터 조회 + 검증 
    # post 요청: request.POST.get('요청파라미터이름') request.POST['이름']
    # get 요청: request.GET.get('요청파라미터이름')  request.GET['이름']
    choice_id = request.POST.get('choice')  # voteform.html에서 갖고온 name =  choice이다.
    # 요청파라미터 검증 : choice로 넘어온 값이 없다면(None) 다시 vote_form으로 이동.
    question_id = request.POST.get('question_id')
    if choice_id == None:
        question = Question.objects.get(pk = question_id)
        return render(request, "polls/vote_form.html",
                        {
                            "question": question,
                            "error_message": "보기를 선택하세요."
                        })


# print(type(request.POST), choice_id, request.POST['choice'])

    # Business logic처리 - 투표처리
    # update할 보기 (Choice)를 조회
    choice = Choice.objects.get(pk= choice_id)
    #vote 의 값을 1증가 시킬거임
    choice.vote += 1
    #update
    choice.save() # pk가 있는거면 update, 없는것면 insert

    # 결과 응답      "url설정이름"         args=[path파라미터에 전달할 값,...,....]
    # redirect 할때는 reverse를 이용해서 url을 만들어 줄 수 있다. 
    url_str =reverse("polls:vote_result", args =[question_id])
    print("---------------------",url_str)
    #return redirect(f"/polls/vote_result/{question_id}")  # 앞쪽은 경로가같으니까 안넣어줌 // 새로 고침. / view에서 전달한 값을 html 파일에서 사용
    return redirect(url_str)
# 한 문제의 투표 결과를 보여주는 view   /polls/vote_result/번호
def vote_result(request, question_id):
    # 조회
    question = Question.objects.get(pk=question_id)
    return render(request, 
                "polls/vote_result.html",
                {"question": question})# 새로고침 해도 상관없으니까 render 씀

