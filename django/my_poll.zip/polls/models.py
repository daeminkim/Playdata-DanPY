from django.db import models

# Question (질문), 
#   - question_text(질문내용)
#   - pub_date(질문 등록일시)
#   - id (PK- 자동생성) :1씩 증가하는 값을 가지도록 자동 생성
# 
# Choice(보기, 선택지)
#   - choice_text(보기내용)
#   - vote(몇번 선택 되었는지)
#   - question(어떤 질문에 대한 보기인지  - Question의 Foreign key 컬럼)
#   - id (PK- 자동생성) :1씩 증가하는 값을 가지도록 자동 생성
#
# Model을 상속받아서 모델을 만든다.
# 컬럼과 연결된 Field들을 class 변수로 선언.
class Question(models.Model):
    #변수명: 컬럼명, 값 : Feild 객체 대입 -> 타입
    question_text = models.CharField(max_length=200) # 200글자 CharFeild == NVACHAR
    pub_date = models.DateTimeField(auto_now_add=True) # auto_now_add: insert될 때 일시를 자동등록(insert)
    #Question에 목록이 나오는 것은 매직 메서드__str__ 을 넣었기 때문에 생성되는 것이다.
    #매직 메서드를 넣지 않으면 그냥  Question object 1 이런식으로 나옴 
    def __str__(self):
        return self.question_text

class Choice(models.Model):
    choice_text = models.CharField(max_length=200)
    vote = models.PositiveIntegerField(default=0) # 0부터 양수만 저장
    question = models.ForeignKey(to = Question, on_delete= models.CASCADE) 
    #to : 참조 Model 클리스 지정./ Choice 테이블에 Question의 id(pk)를 Forign key로 넣어서 질문과 답을 짝지을 것이다.
    #  # on_delete: 부모테이블의 값이 delete될 경우 처리 방식. CASCADE : 참조하는 자식데이터도 같이 삭제
    #question = models.ForeignKey(to = Question, on_delete= models.CASCADE)  
    # 이것을 지정했기 때문에 테스트 서버에서 나온다
    def __str__(self):
        return self.choice_text 



