from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Question, Choice
from django.urls import reverse  # reverse함수: path 설정 이름으로 url 문자열을 만들어 주는 함수.

from django.views.generic import ListView , View, DetailView# 모든 View ~ pdf보기 

# ListView -모델의 전체 데이터를 조회해서 template에게 전달. (paging 기능 제공)
class QuestionListView(ListView):
    model = Question # 전체 데이터를 조회할 모델 클래스 지정 // Question.objects.all()  이것을 ListView가 대신해준다.
    template_name = 'polls/list.html'  #응댑할 template 의 경로 
    # 조회결과를 template에게 전달  
    # 전달할 때 이름 필요하니까- 이름: model 클래스명 (소문자)_list, 'object_list' 
    # -->함수형으로 할때는 딕셔너리 형태로 key(이름을 정해주지만) class로 할때는 알아서 값을 넘겨주기때문에 이름을 위의 형식으로 보낸다. 
    # 다른이름으로 전달할 경우 : context_object_name ='전송할이름'
    #  
# 투표작업을 처리
# GET 요청: 투표 양식(vote_form) 전달
# POST 요청: 투표 처리(vote) // alt 누르고 같은 변수들 다선택하면 한번에 수정가능하다.
class VoteView(View):  # 이렇게 나눠서 처리해주는 제너릭 뷰는 따로 없어서 그냥 View를 사용한다.
    #get 방식 요청
    def get(self, request, *args, **kwargs ): #메서드 니까 self받고
        #kwargs(키워드 가변인자) : path parameter를 조회. 
        print("------------------------------VoteView.get()")
        question_id = kwargs['question_id']
        try:
            question = Question.objects.get(pk = question_id)
            return render(request,
                          "polls/vote_form.html",{"question":question}) 
        except:
            return render(request, 'polls/error.html',
                      {'error_message' : "없는 질문을 조회했어"})
    
    # post방식 요청처리 
    def post(self, request, *args, **kwargs):
        choice_id = request.POST.get('choice')
    # 요청파라미터 검증 : choice로 넘어온 값이 없다면(None) 다시 vote_form으로 이동.
        
        #question_id = request.POST.get('question_id')
        question_id = kwargs['question_id']# path parameter
        if choice_id == None:
            question = Question.objects.get(pk = question_id)
            return render(request, "polls/vote_form.html",
                            {
                                "question": question,
                                "error_message": "보기를 선택하세요."
                            })

        choice = Choice.objects.get(pk= choice_id)
        #vote 의 값을 1증가 시킬거임
        choice.vote += 1
        #update
        choice.save() # pk가 있는거면 update, 없는것면 insert

    
        url_str =reverse("polls:vote_result", args =[question_id])
        print("---------------------",url_str)
        #return redirect(f"/polls/vote_result/{question_id}")  # 앞쪽은 경로가같으니까 안넣어줌 // 새로 고침. / view에서 전달한 값을 html 파일에서 사용
        return redirect(url_str)


# DetailView :특정 모델의 Primary key를 받아서 조회한 결과를 template에 전달.
# primary key는 path parameter로 받아야 한다. urls.py 에서 path parameter의 변수 명은 <타입: pk>
# question의 id(pk)를 받아서 질문하나를 조회한 후에 template(vote_result.html)  --> 모든뷰 함수형으로 만든것과 비교해 보자 
class QuestionDetailView(DetailView):  # 로직이 없을때는 클래스 구현안하고 urls.py 에 바로 구현해도 된다. (ex - DetailVeiw, ListView)
    model = Question # 데이터를 조회할 Model 클래스 지정
    template_name = "polls/vote_result.html" # 이동할 template 경로

    





