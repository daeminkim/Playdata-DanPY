from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView  # genericview아님 ..
from django.contrib.auth.forms import UserCreationForm

from django.views.generic import CreateView 
from django.urls import reverse_lazy

app_name = 'account'

urlpatterns =[
    # LoginView - GET 요청 : template_name의 template으로 이동 (render()) ->로그인 입력폼.
    #             Post요청 : 요청파라미터로 받은 username/password로 로그인 처리 
    path("login", LoginView.as_view(template_name ='account/login_form.html'), name ='login'),
    #LogoutView - 로그아웃처리 후에 settings.py의 LOGOUT_REDIRECT_URL의 설정 url로 이동.
    path('logout', LogoutView.as_view(), name ='logout'),
    #UserCreationForm: 
    # username, password1, password2 입력을 받아 username과 password 를 등록한다.
    path('join', CreateView.as_view(template_name ='account/join_form.html',
                                    form_class = UserCreationForm,
                                    success_url= reverse_lazy('account:login')), 
                                    name ='join' ),
]