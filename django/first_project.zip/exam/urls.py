# exam /urls.py 
from django.urls import path
from . import views  # 같은 경로에 있는 from . 파일을 import 한다.. 
 # views에 있는 함수를 갖고 와야하니까 import 해준다.// 어떤 함수인지 views.hello1
urlpatterns = [
    # http://ip:port/exam/hello1(http://127.0.0.1:8000/exam/hello1)를 입력하면  -> views.hello1 함수를 실행한다는 .. 
    path("hello1", views.hello1, name ='hello1'), #/ 어떤 함수인지 views.hello1 을 넣어 줬다. name은 필수적으로 넣고. 
    path("hello2", views.hello2, name ='hello2'),  #http://127.0.0.1:8000/exam/hello2
]