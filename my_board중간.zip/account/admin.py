from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser




# UserAdmin : 관리자앱에서 사용자 관리 화면 -> customizing
class CustomUserAdmin(UserAdmin):  # pdf 14페이지
    #기본정보 카테고리 설정
    UserAdmin.fieldsets[1][1]['fields'] = ('name','email','gender')
    # 사용자 목록에 나올 
    list_display =['username','name','email']



admin.site.register(CustomUser, CustomUserAdmin)
