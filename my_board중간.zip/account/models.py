from django.db import models
from django.contrib.auth.models import AbstractUser

#사용자 정의 User모델 -> AbstractUser 확장(상속): 기존 User모델 +추가Field
# settings.py 에 User모델로 등록 (AUTH_USERMODEL)
# python manage.py makemigrations  //모델 만들었으니까 db에 생성시켜야함.잊지마~ // 처음 루트 테이블에서 만들어졌던 데이터베이스와 엉켜서 기존의 것을 삭제하고 다시 migrate했음
#그리고 전의 것을 삭제 했기때문에 수퍼유져를 다시 생성함 
class CustomUser(AbstractUser):
    # Model Field 작성 => 추가 User Field
    GENDER_CHOICE =[
        ['M', '남성'], # <option value ='M'>남성</option>
        ['F', '여성']   # index 0: 전송될값, index1:입력양식에 보여질 값.
    ]

    name = models.CharField(verbose_name='이름', max_length= 100)
    email = models.EmailField(verbose_name= '이메일', max_length= 100)
    gender = models.CharField(verbose_name= '성별', max_length= 1, choices=GENDER_CHOICE)

    def __str__(self):
        return f"{self.pk}. {self.name}"